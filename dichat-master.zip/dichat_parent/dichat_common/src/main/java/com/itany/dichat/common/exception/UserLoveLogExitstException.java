package com.itany.dichat.common.exception;/**
 * @author:GodFrey
 * @date:2019/12/4/004.
 */

/**
 * Created by IntelliJ IDEA.
 * User: Godfrey
 * Date: 2019/12/4/004
 * Time: 17:08
 * File Name: 
 */
public class UserLoveLogExitstException extends Exception {
    public UserLoveLogExitstException() {
        super();
    }

    public UserLoveLogExitstException(String message) {
        super(message);
    }

    public UserLoveLogExitstException(String message, Throwable cause) {
        super(message, cause);
    }

    public UserLoveLogExitstException(Throwable cause) {
        super(cause);
    }
}
